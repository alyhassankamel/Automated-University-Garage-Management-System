package AUGMS.entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class PaymentMethod {

    /**
     * Default constructor
     */
    public PaymentMethod() {
    }

    /**
     * 
     */
    private String methodID;

    /**
     * 
     */
    private String methodType;

    /**
     * 
     */
    private String details;



    /**
     * @param amount 
     * @return
     */
    public PaymentResult processPayment(Double amount) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void validateMethod() {
        // TODO implement here
        return null;
    }

}
