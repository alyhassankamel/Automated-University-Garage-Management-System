package AUGMS.entity;

/**
 * 
 */
enum InvoiceStatus {
    PENDING,
    PAID,
    CANCELLED
}
