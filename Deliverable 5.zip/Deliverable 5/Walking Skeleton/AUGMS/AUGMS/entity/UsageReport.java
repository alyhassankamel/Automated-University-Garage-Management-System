package AUGMS.entity;

import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

/**
 * 
 */
public class UsageReport {

    /**
     * Default constructor
     */
    public UsageReport() {
    }

    /**
     * 
     */
    private String reportID;

    /**
     * 
     */
    private LocalDateTime startDate;

    /**
     * 
     */
    private LocalDateTime endDate;

    /**
     * 
     */
    private String format;




    /**
     * @return
     */
    public String getReportID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public Document generateReport() {
        // TODO implement here
        return null;
    }

}
