package AUGMS.entity;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class GarageAdmin {

    /**
     * Default constructor
     */
    public GarageAdmin() {
    }

    /**
     * 
     */
    private String uniID;

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private String phone;

    /**
     * 
     */
    private String adminID;


    /**
     * @param alert 
     * @return
     */
    public void receiveSensorErrorAlert(SensorAlert alert) {
        // TODO implement here
        return null;
    }

    /**
     * @param alert 
     * @return
     */
    public ImpactAssessment assessErrorImpact(SensorAlert alert) {
        // TODO implement here
        return null;
    }

    /**
     * @param alert 
     * @return
     */
    public void initiateResponseActions(SensorAlert alert) {
        // TODO implement here
        return null;
    }

    /**
     * @param alert 
     * @return
     */
    public void notifyUniversityManager(SensorAlert alert) {
        // TODO implement here
        return null;
    }

}
