package AUGMS.entity;

/**
 * 
 */
enum GateStatus {
    OPEN,
    CLOSED,
    ERROR
}
