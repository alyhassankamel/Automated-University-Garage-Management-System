package AUGMS.entity;

/**
 * 
 */
enum RegistrationStatus {
    PENDING,
    APPROVED,
    REJECTED
}
