package AUGMS.entity;

/**
 * 
 */
enum PaymentStatus {
    SUCCESS,
    FAILED,
    PENDING
}
