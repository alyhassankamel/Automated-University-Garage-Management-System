package AUGMS.entity;

import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

/**
 * 
 */
public class ServiceLog {

    /**
     * Default constructor
     */
    public ServiceLog() {
    }

    /**
     * 
     */
    private String logID;

    /**
     * 
     */
    private String requestID;

    /**
     * 
     */
    private String serviceID;

    /**
     * 
     */
    private LocalDateTime timestamp;

    /**
     * 
     */
    private String status;



    /**
     * @return
     */
    public String getLogID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public void getTimestamp() {
        // TODO implement here
        return null;
    }

}
