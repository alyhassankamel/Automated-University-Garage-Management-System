package AUGMS.entity;

/**
 * 
 */
public enum SpotStatus {
    OCCUPIED,
    AVAILABLE,
    OUT_OF_SERVICE
}
