package AUGMS.entity;

import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

/**
 * 
 */
public class ErrorLog {

    /**
     * Default constructor
     */
    public ErrorLog() {
    }

    /**
     * 
     */
    private String logID;

    /**
     * 
     */
    private String sensorID;

    /**
     * 
     */
    private String errorType;

    /**
     * 
     */
    private LocalDateTime date;

    /**
     * 
     */
    private String details;


    /**
     * @return
     */
    public String getLogID() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getErrorType() {
        // TODO implement here
        return "";
    }

}
