package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class PaymentMethodDAO {

    /**
     * Default constructor
     */
    public PaymentMethodDAO() {
    }



    /**
     * @return
     */
    public void findPaymentMethod() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void processPayment() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void validatePaymentMethod() {
        // TODO implement here
        return null;
    }

}
