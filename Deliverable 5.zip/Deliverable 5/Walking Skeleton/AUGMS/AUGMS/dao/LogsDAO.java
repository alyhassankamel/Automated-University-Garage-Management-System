package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class LogsDAO {

    /**
     * Default constructor
     */
    public LogsDAO() {
    }





    /**
     * @return
     */
    public void saveReport() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void findReport() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void getAllReports() {
        // TODO implement here
    }

}
