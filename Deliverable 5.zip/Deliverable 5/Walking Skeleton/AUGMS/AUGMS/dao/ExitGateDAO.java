package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ExitGateDAO {

    /**
     * Default constructor
     */
    public ExitGateDAO() {
    }



    /**
     * @return
     */
    public void findGate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void openGate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void closeGate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getGateStatus() {
        // TODO implement here
        return null;
    }

}
