package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class EntryGateDAO {

    /**
     * Default constructor
     */
    public EntryGateDAO() {
    }



    /**
     * @return
     */
    public void findGate() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void openGate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void closeGate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getGateStatus() {
        // TODO implement here
        return null;
    }

}
