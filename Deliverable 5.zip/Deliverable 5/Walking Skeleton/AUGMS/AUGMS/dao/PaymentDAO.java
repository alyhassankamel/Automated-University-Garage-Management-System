package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class PaymentDAO {

    /**
     * Default constructor
     */
    public PaymentDAO() {
    }



    /**
     * @return
     */
    public void createPayment() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findPayment() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updatePaymentStatus() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getPaymentsByRequest() {
        // TODO implement here
    }

}
