package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class SensorDAO {

    /**
     * Default constructor
     */
    public SensorDAO() {
    }



    /**
     * @return
     */
    public void findSensor() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void getAllSensors() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void updateSensorStatus() {
        // TODO implement here
        return null;
    }

}
