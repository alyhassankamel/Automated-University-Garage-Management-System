package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class GarageAdminDAO {

    /**
     * Default constructor
     */
    public GarageAdminDAO() {
    }





    /**
     * @return
     */
    public void findAdmin() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void findAdminByUniID() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void validateCredentials() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void updateAdmin() {
        // TODO implement here
        return null;
    }

}
