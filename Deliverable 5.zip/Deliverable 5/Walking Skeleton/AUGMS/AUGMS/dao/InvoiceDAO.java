package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class InvoiceDAO {

    /**
     * Default constructor
     */
    public InvoiceDAO() {
    }




    /**
     * @return
     */
    public void createInvoice() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void findInvoice() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void updateInvoice() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void getInvoicesByRequest() {
        // TODO implement here
    }

}
