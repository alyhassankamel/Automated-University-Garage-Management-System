package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ParkingStatusDAO {

    /**
     * Default constructor
     */
    public ParkingStatusDAO() {
    }



    /**
     * @return
     */
    public void getParkingStatus() {
        // TODO implement here
        return null;
    }

}
