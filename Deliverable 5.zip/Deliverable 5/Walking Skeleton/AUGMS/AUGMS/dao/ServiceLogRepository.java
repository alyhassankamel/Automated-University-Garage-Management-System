package AUGMS.dao;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class ServiceLogRepository {

    /**
     * Default constructor
     */
    public ServiceLogRepository() {
    }



    /**
     * @return
     */
    public void getServiceLogs() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void createServiceLog() {
        // TODO implement here
        return null;
    }

}
