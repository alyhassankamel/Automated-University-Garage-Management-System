package controller;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class RegistrationController {

    /**
     * Default constructor
     */
    public RegistrationController() {
    }



    /**
     * @return
     */
    public void handleRegistrationRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleConfirmation() {
        // TODO implement here
        return null;
    }

}
