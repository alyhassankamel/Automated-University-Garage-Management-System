package controller;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class UserAccessController {

    /**
     * Default constructor
     */
    public UserAccessController() {
    }



    /**
     * @return
     */
    public void handleAccessChangeRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleAccessChangeConfirmation() {
        // TODO implement here
        return null;
    }

}
