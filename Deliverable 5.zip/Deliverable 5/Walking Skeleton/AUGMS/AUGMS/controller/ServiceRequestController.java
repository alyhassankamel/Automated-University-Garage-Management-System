package controller;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ServiceRequestController {

    /**
     * Default constructor
     */
    public ServiceRequestController() {
    }



    /**
     * @return
     */
    public void handleServiceRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handleInvoiceGeneration() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void handlePaymentProcessing() {
        // TODO implement here
        return null;
    }

}
