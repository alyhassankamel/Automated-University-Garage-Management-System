package AUGMS.service;

import AUGMS.dao.VehicleDAO;
import AUGMS.dao.ParkingUserDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleUpdateService {

    /**
     * Default constructor
     */
    public VehicleUpdateService() {
    }

    /**
     * 
     */
    private final VehicleDAO vehicleDAO;

    /**
     * 
     */
    private final ParkingUserDAO parkingUserDAO;






    /**
     * @return
     */
    public void getVehicleDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void validateVehicleOwnership() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void validateUpdatedData() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void updateVehicleDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void saveUpdatedVehicle() {
        // TODO implement here
        return null;
    }

}
