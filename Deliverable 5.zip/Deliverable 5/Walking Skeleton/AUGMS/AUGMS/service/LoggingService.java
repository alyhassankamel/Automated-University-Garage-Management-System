package AUGMS.service;

import AUGMS.dao.LoggingDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class LoggingService {

    /**
     * Default constructor
     */
    public LoggingService() {
    }

    /**
     * 
     */
    private final LoggingDAO loggingDAO;














    /**
     * @return
     */
    public void recordRegistration() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordEntry() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordExit() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordAccessChange() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordVehicleUpdate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordSensorErrorAlert() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordPaymentSuccess() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordPaymentFailure() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordParkingStatusView() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getLogsByType() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void provideErrorLogsForReport() {
        // TODO implement here
        return null;
    }

}
