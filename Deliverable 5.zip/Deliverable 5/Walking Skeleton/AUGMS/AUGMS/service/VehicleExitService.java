package AUGMS.service;

import AUGMS.dao.VehicleDAO;
import AUGMS.dao.ParkingGarageDAO;
import AUGMS.dao.ExitGateDAO;
import AUGMS.dao.OccupancySensorDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleExitService {

    /**
     * Default constructor
     */
    public VehicleExitService() {
    }

    /**
     * 
     */
    private final VehicleDAO vehicleDAO;

    /**
     * 
     */
    private final ParkingGarageDAO parkingGarageDAO;

    /**
     * 
     */
    private final ExitGateDAO exitGateDAO;

    /**
     * 
     */
    private final OccupancySensorDAO occupancySensorDAO;






    /**
     * @return
     */
    public void validateVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getParkingDuration() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void processExit() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void openExitGate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void updateSpotStatus() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordExit() {
        // TODO implement here
        return null;
    }

}
