package AUGMS.service;

import AUGMS.dao.ParkingUserDAO;
import AUGMS.dao.GarageAdminDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class AuthenticationService {

    /**
     * Default constructor
     */
    public AuthenticationService() {
    }

    /**
     * 
     */
    private final ParkingUserDAO parkingUserDAO;

    /**
     * 
     */
    private final GarageAdminDAO garageAdminDAO;







    /**
     * @return
     */
    public void validateCredentials() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void authenticateUser() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void checkAccessPermissions() {
        // TODO implement here
        return null;
    }

}
