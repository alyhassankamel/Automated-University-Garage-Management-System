package AUGMS.service;

import AUGMS.dao.EntryExitRepository;
import AUGMS.dao.ServiceLogRepository;
import AUGMS.dao.LogsDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ReportService {

    /**
     * Default constructor
     */
    public ReportService() {
    }

    /**
     * 
     */
    private final EntryExitRepository entryExitRepository;

    /**
     * 
     */
    private final ServiceLogRepository serviceLogRepository;

    /**
     * 
     */
    private final LogsDAO logsDAO;





    /**
     * @return
     */
    public void compileUsageReport() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void generateReport() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void saveReport() {
        // TODO implement here
        return null;
    }

}
