package AUGMS.service;

import AUGMS.dao.VehicleDAO;
import AUGMS.dao.ParkingGarageDAO;
import AUGMS.dao.OccupancySensorDAO;
import AUGMS.dao.EntryGateDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleEntryService {

    /**
     * Default constructor
     */
    public VehicleEntryService() {
    }

    /**
     * 
     */
    private final VehicleDAO vehicleDAO;

    /**
     * 
     */
    private final ParkingGarageDAO parkingGarageDAO;

    /**
     * 
     */
    private final OccupancySensorDAO occupancySensorDAO;

    /**
     * 
     */
    private final EntryGateDAO entryGateDAO;






    /**
     * @return
     */
    public void validateRegistration() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void checkOccupancy() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void openGate() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void createEntryLog() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void incrementOccupiedSpots() {
        // TODO implement here
        return null;
    }

}
