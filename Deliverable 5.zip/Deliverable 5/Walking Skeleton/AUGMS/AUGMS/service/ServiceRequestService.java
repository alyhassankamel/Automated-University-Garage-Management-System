package AUGMS.service;

import AUGMS.dao.ServiceRequestDAO;
import AUGMS.dao.ParkingSpotDAO;
import AUGMS.dao.ServiceTypeDAO;
import AUGMS.dao.ParkingUserDAO;
import AUGMS.dao.VehicleDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ServiceRequestService {

    /**
     * Default constructor
     */
    public ServiceRequestService() {
    }

    /**
     * 
     */
    private final ServiceRequestDAO serviceRequestDAO;

    /**
     * 
     */
    private final ParkingSpotDAO parkingSpotDAO;

    /**
     * 
     */
    private final ServiceTypeDAO serviceTypeDAO;

    /**
     * 
     */
    private final ParkingUserDAO parkingUserDAO;

    /**
     * 
     */
    private final VehicleDAO vehicleDAO;












    /**
     * @return
     */
    public void getSpotDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getAvailableServicesForSpot() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void createServiceRequest() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void associateRequester() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void associateVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void generateInvoice() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void processPayment() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void updateRequestStatus() {
        // TODO implement here
        return null;
    }

}
