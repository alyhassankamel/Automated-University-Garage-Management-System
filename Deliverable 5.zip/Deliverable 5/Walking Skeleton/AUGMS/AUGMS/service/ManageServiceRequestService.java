package AUGMS.service;

import AUGMS.dao.ServiceRequestDAO;
import AUGMS.dao.GarageAdminDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ManageServiceRequestService {

    /**
     * Default constructor
     */
    public ManageServiceRequestService() {
    }

    /**
     * 
     */
    private final ServiceRequestDAO serviceRequestDAO;

    /**
     * 
     */
    private final GarageAdminDAO garageAdminDAO;

    /**
     * 
     */
    private ServiceRequestService serviceRequestService;






    /**
     * @return
     */
    public void getAllServiceRequests() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void updateRequestStatus() {
        // TODO implement here
        return null;
    }

}
