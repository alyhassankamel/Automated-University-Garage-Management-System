package AUGMS.service;

import AUGMS.dao.PaymentDAO;
import AUGMS.dao.PaymentMethodDAO;
import AUGMS.dao.InvoiceDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class PaymentService {

    /**
     * Default constructor
     */
    public PaymentService() {
    }

    /**
     * 
     */
    private final PaymentDAO paymentDAO;

    /**
     * 
     */
    private final PaymentMethodDAO paymentMethodDAO;

    /**
     * 
     */
    private final InvoiceDAO invoiceDAO;






    /**
     * @return
     */
    public void createPayment() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void processPayment() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordPaymentSuccess() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void recordPaymentFailure() {
        // TODO implement here
        return null;
    }

}
