package AUGMS.service;

import AUGMS.dao.ParkingUserDAO;
import AUGMS.dao.VehicleDAO;
import java.io.*;
import java.util.*;

/**
 * 
 */
public class RegistrationService {

    /**
     * Default constructor
     */
    public RegistrationService() {
    }

    /**
     * 
     */
    private final ParkingUserDAO parkingUserDAO;

    /**
     * 
     */
    private final VehicleDAO vehicleDAO;





    /**
     * @return
     */
    public void createUser() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void createVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void associateVehicle() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void validateDetails() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void confirmRegistration() {
        // TODO implement here
        return null;
    }

}
