package AUGMS.service;

import AUGMS.dao.InvoiceDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class InvoiceService {

    /**
     * Default constructor
     */
    public InvoiceService() {
    }

    /**
     * 
     */
    private final InvoiceDAO invoiceDAO;



    /**
     * @return
     */
    public void generateInvoice() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void calculateAmount() {
        // TODO implement here
        return null;
    }

}
