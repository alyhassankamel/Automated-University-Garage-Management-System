package AUGMS.service;

import AUGMS.dao.ParkingUserDAO;
import AUGMS.dao.VehicleDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class VehicleManagementService {

    /**
     * Default constructor
     */
    public VehicleManagementService() {
    }

    /**
     * 
     */
    private final ParkingUserDAO parkingUserDAO;

    /**
     * 
     */
    private final VehicleDAO vehicleDAO;

    /**
     * 
     */
    private AuthenticationService authenticationService;





    /**
     * @return
     */
    public void validateCredentials() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void getPendingRegistrations() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void acceptUser() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void rejectUser() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void checkIfUrgentMember() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void grantAccess() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void forbidAccess() {
        // TODO implement here
        return null;
    }

}
