package AUGMS.service;

import java.io.*;
import java.util.*;

/**
 * ...
 */
public class ReportGenerator {

    /**
     * Default constructor
     */
    public ReportGenerator() {
    }


    /**
     * @return
     */
    public void generateReport() {
        // TODO implement here
        return null;
    }

}
