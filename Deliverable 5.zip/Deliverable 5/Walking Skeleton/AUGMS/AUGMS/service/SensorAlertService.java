package AUGMS.service;

import AUGMS.dao.SensorDAO;
import AUGMS.dao.OccupancySensorDAO;
import AUGMS.dao.GateSensorDAO;
import AUGMS.dao.GarageAdminDAO;
import AUGMS.dao.UniversityManagerDAO;
import java.io.*;
import java.util.*;

/**
 * ...
 */
public class SensorAlertService {

    /**
     * Default constructor
     */
    public SensorAlertService() {
    }

    /**
     * 
     */
    private final SensorDAO sensorDAO;

    /**
     * 
     */
    private final OccupancySensorDAO occupancySensorDAO;

    /**
     * 
     */
    private final GateSensorDAO gateSensorDAO;

    /**
     * 
     */
    private final GarageAdminDAO garageAdminDAO;

    /**
     * 
     */
    private final UniversityManagerDAO universityManagerDAO;








    /**
     * @return
     */
    public void performSelfDiagnostics() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void detectFault() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void generateErrorAlert() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void reportAlertToLogging() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void receiveSensorErrorAlert() {
        // TODO implement here
        return null;
    }

    /**
     * ...
     * @return
     */
    public void notifyUniversityManager() {
        // TODO implement here
        return null;
    }

}
